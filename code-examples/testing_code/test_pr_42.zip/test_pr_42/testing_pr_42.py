from scalesim.scale_sim import scalesim


if __name__ == '__main__':
    config = './scale_8x8_is.cfg'
    topology = './test_simple.csv'

    s = scalesim(save_disk_space=False, verbose=True,
                 config=config,
                 topology=topology,
                 input_type_gemm=False
                 )

    logpath = './'
    s.run_scale(top_path=logpath)